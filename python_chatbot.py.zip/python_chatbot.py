#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Jan 29 13:50:05 2017

@author: kelseydonavin
"""

#Programmer: Kelsey Donavin
#Class: CptS 111-01, Spring 2017
#Programming Assignment 1
#2/1/2017
#
#Description: A simple chatbot program that interacts with the user in a fun way, that also eventually discusses the user's dream car and calculates monthly payments.

user_name = input("Oh look, a friend! My name is Chatty Chatbot, what's yours? \n")
#Asks for the users name, and assigns the input to user_name for later use.

print("\n%s...Hmmmm.. your name sounds very familiar.\nHave we met before? Silly me, of course we haven't! I am only two hours old."%(user_name))
#Prints a commentary on the user's name.

print("Sadly, I've only been alive long enough to know a few people.")

user_place = input("Where are you from?\n")
#Asks user where they are from, and assigns that input to user_place.

print("%s? That's neat! I've never been there before.\nThe only place I've ever been to is the basement of Glenn Terrell Library in Washington State University."%(user_place))

user_age_year = int(input("What year were you born?\n"))
#Asks the user was born, and assigns the input to user_age_year.

user_age = 2017 - user_age_year
#Calculates the user's age, assigns it to variable user_age.

bot_age = 2.0
#Bot's age in hours is assigned to bot_age

bot_age_years = 2 / (365 * 24)
#Turns the bots age into years

age_difference = user_age / bot_age_years
#Calculates how many times older the user is than the bot 

age_difference_hours = (user_age * 365 * 24) - bot_age
#Calculates the age difference in hours between the user and bot by multiplying the user's age (in years) by 365 and 24 to change the user's age into hours, than subtracts bot_age to get the difference.

print("Wow! That means you are %.2f hours older than me, which is %.2f times older than me!"%(age_difference_hours,age_difference))
#Prints a statement that tells the user the age difference

dream_car = input("Certainly someone of your age and beauty must have some big dreams!\nWhat is your dream car?\n")
#Asks the user what their dream car is and assigns it to the variable dream_car

print("No way! Me too! I would love to have the %s."%(dream_car))

print("Fun fact: the U.S. government wants every new vehichle to have an average mile per gallon of 34.1!")

dream_car_mpg = float(input("What happens to be the average miles per gallon of the %s?\n"%(dream_car)))
#Asks the user for the avg mpg, then changes the type from str to float and assigns it to the variable dream_car_mpg.

if dream_car_mpg < 34.1:
    print("That's less than the government's desired average.")
elif dream_car_mpg == 34.1:
    print("That's exactly the average that the government wants.")
elif dream_car_mpg > 34.1:
    print("Wow, that's above the government's desired average! Good for you!")
#Prints a different statement depending on whether the dream_car_mpg is less than, equal to, or greater than 34.1.

dream_car_cost = float(input("How much does the %s cost?\n"%(dream_car)))
#Asks the user how much dream_car would cost, and changes the type from string to float.

if dream_car_cost <= 33000.0:
    print("Gee, what a bargain!")
elif dream_car_cost > 33000.0:
    print("Wow, that sure is expensive!")
#Prints one statement if dream_car_cost is less than or equal to 33000 and prints another statement if the dream_car_cost is higher than 33000.

loan_years = int(input("For how many years would you take out a loan to pay for the %s?\n"%(dream_car)))
#Asks the user how many years they would take for a loan, then changes the input from str to int, then assigns it to the variable loan_years.

interest_rate_percent = float(input("And, what annual interest rate would you expect to get?\n"))
#Asks the user for the annual interest rate, then changes the input from str to float, then assigns it to the variable interest_rate_percent.

interest_rate = (interest_rate_percent / 100) / 12
#Calculates annual interest rate by converting the interest rate from a percent to a decimal then dividing by 12(months per year).

loan_months = loan_years * 12
#Changes the amount of years for the loan into months by multiplying by 12.

monthly_payment = (interest_rate * dream_car_cost) / (1 - (1 + interest_rate)**(-1 * loan_months))
#Calculates the monthly payment by using the annual interest rate, the cost of the car, and the amount of loan months.

print("That means that the monthly payments for your %s would be $ %.2f ."%(dream_car,monthly_payment))
#Displays to the user the monthly payments for their dream car.

total_price = monthly_payment * loan_months
#Calculates the total cost with all the monthly payments of the user's dream car by multiplying the monthly payment by the amount of time the user plans to take out a loan in months(loan_months).

print("That's a grand total of $ %.2f! I hope you can afford that, I know I sure can't!"%(total_price))

print("Well, this has been fun, but I have to go now. See you later, %s!"%(user_name))

#Citations:
#http://nbviewer.jupyter.org/github/gsprint23/cpts111/blob/master/progassignments/PA1.ipynb