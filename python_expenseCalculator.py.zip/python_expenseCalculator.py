#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Feb  6 14:46:38 2017

@author: kelseydonavin
"""

#Programmer: Kelsey Donavin
#Class: CptS 111-01, Spring 2017
#Programming Assignment 1
#2/1/2017
#
#Description: Program that calculates the cost of a night out involving dinner and a movie.

import math

import matplotlib.pyplot as plt
    
def display_instructions():
    '''
    This function prints(displays) a brief explanation of the program to the user.
    '''
    print("Welcome to the night out simulator! This program will prompt you for the sales tax (as a percent) in your state. Then it will walk you through your night out on the town, starting with dinner and ending with a movie! The total amount of money spent for the evening will be kept track of, so you know how much your credit card bill will be!\n")
    
    
def get_state_sales_tax():
    '''
    Prompts the user for the state sales tax (percent), then assigns it to the local variable state_sales_tax, and returns it.
    '''
    state_sales_tax = float(input("Please enter the state sales tax: \n"))
    return state_sales_tax
    
def get_price(activity):
    '''
    Prompts user for the price of an activity, accepts the single argument 'activity', and returns the price of said activity inputed by the user.
    '''
    price = float(input("Please enter the price of %s before tax: \n"%(activity)))
    return price
    
def get_cost_parking(activity):
    '''
    This function calls the get_price() function which prompts the user to input a price for parking. Then returns the price of parking.
    '''
    cost_parking = get_price(activity)
    return cost_parking
    
def get_tip_percent():
    '''
    Prompts the user for the percent they would like to tip of the dinner bill, then returns the tip percent.
    '''
    tip_percent = float(input("Please enter the percentage of the dinner bill you would like to tip: \n"))
    return tip_percent
       
def calculate_tax(price,state_sales_tax):
    '''
    Calculates the amount of tax for the price, then returns the amount of tax in dollars. 
    '''
    tax = (state_sales_tax / 100) * price
    return tax
    
def calculate_tip(price,tip_percent):
    '''
    Calculates the amount of tip based on the price, then returns the amount of tip in dollars. This function accepts the arguments price (activity price plus tax) and tip percent.
    '''
    tip = (tip_percent / 100) * price
    return tip
    
def round_up_dollar(price):
    '''
    Rounds up the end price of the activity to the nearest dollar, accepts the argument price(final price of activity including tip and tax).
    '''
    price_rounded = math.ceil(price)
    return price_rounded
    
def go_to_dinner(state_sales_tax):
    '''
    Calculates the total cost of dinner by calling the get_price(), get_tip_percent(), calculate_tax(), calculate_tip(), and the round_up_dollar() functions. It accepts the argument state_sales_tax, and returns the total cost of dinner.
    '''
    dinner_price = get_price("dinner")
    tip_percent = get_tip_percent()
    dinner_tax = calculate_tax(dinner_price,state_sales_tax)
    dinner_end_cost = dinner_price + dinner_tax
    tip = calculate_tip(dinner_end_cost,tip_percent)
    dinner_end_cost += tip
    dinner_end_cost_rounded = round_up_dollar(dinner_end_cost)
    return dinner_end_cost_rounded
    
def go_to_movie(state_sales_tax):
    '''
    Calculates the total cost of the movie after tax by calling the get_price() and the calculate_tax() fucntion. It accepts the argument state_sales_tax, and returns the total price of going to the movie.
    '''
    movie_price = get_price("movie")
    movie_tax = calculate_tax(movie_price,state_sales_tax)
    movie_end_cost = movie_price + movie_tax
    return movie_end_cost
    
def display_money_spent(dinner_end_cost_rounded,movie_end_price,end_parking):
    '''
    Displays the total costs of the night to the user, accepts the arguments dinner_end_cost, movie_end_price, and end_parking.
    '''
    total_night_cost = end_parking + dinner_end_cost_rounded + movie_end_price
    print("Including tax and tip, you spent $%.2f on dinner."%(dinner_end_cost_rounded))
    print("Including tax, you spent $%.2f on the movie."%(movie_end_price))
    print("For parking at dinner, and at the movie; you spent $%.2f total."%(end_parking))
    print("You spent a total of $%.2f tonight."%(total_night_cost))
    
def plot_money_spent(dinner,dinner_end_cost_rounded,movie,movie_end_cost,parking,end_parking_cost):
    '''
    Plots the total costs of dinner, movie, and parking as a bar graph, accepts the parameters dinner, movie, parking, dinner_end_cost_rounded, movie_end_cost, and end_parking_cost.
    '''
    x = [0,1,2]
    x_labels = [dinner,movie,parking]
    y = [dinner_end_cost_rounded,movie_end_cost,end_parking_cost]
    plt.bar(x,y)
    plt.xticks(x,x_labels,ha='left')
    plt.xlabel("Activity")
    plt.ylabel("Price in Dollars")
    plt.tight_layout()
    plt.show() 
    
def main():
    '''
    Drives the program by calling several functions. It calls the display_instructions(), get_state_sales_tax(), get_cost_parking(), go_to_dinner(), go_to_movie(), display_money_spent(), plot_money_spent() fucntions.
    '''
    display_instructions()
    state_sales_tax = get_state_sales_tax()
    dinner_parking = get_cost_parking("dinner parking")
    dinner_end_cost_rounded = go_to_dinner(state_sales_tax)
    movie_parking = get_cost_parking("movie parking")
    movie_end_cost = go_to_movie(state_sales_tax)
    end_parking_cost = dinner_parking + movie_parking
    display_money_spent(dinner_end_cost_rounded,movie_end_cost,end_parking_cost)
    activity1 = "Dinner"
    activity2 = "Movie"
    activity3 = "Parking"
    plot_money_spent(activity1,dinner_end_cost_rounded,activity2,movie_end_cost,activity3,end_parking_cost)
    
main()
#Calls the main function.
    
#Citations:
    # Gina Sprint
    # Izak Kam
    # http://nbviewer.jupyter.org/github/gsprint23/cpts111/blob/master/progassignments/PA2.ipynb
   

