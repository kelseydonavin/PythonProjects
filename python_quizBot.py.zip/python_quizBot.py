#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sun Feb 26 12:39:16 2017

@author: kelseydonavin
"""

#Programmer: Kelsey Donavin
#Class: CptS 111-01, Spring 2017
#Programming Assignment 3
#2/26/2017
#
#Description: 10 question "Are you a fan?" quiz about the TV show, Modern Family.

print("Welcome to the Modern Family Quiz!\nThis quiz will determine how much of a true Modern Family fan you are!")
    
def question_1():
    ''' 
    The fucntion question_1() is a mutliple choice question, it accepts no arguments and returns 1 if the user gets the answer correct and zero if the user answers incorrectly.
    '''
    print("1. Which answer is not a character on Modern Family?\n Please enter a character a-e.")
    answer_1 = input(" a. Cameron Tucker\n b. Joe Pritchett\n c. Ed Dunphy\n d. Manny Delgado\n e. Pilar\n Answer: ")
    if answer_1 == "c":
        print("You are correct!\n")
        return 1
    else:
        print("Sorry, that's wrong, the correct answer is actually Ed Dunphy (c).\n")
        return 0
        
def question_2():
    '''
    The fucntion question_2() is a numeric response question, it accepts no arguments and returns 1 if the user gets the answer correct and zero if the user answers incorrectly. 
    '''
    answer_2 = int(input("2. How many seasons has Modern Family aired for?\n Please enter an integer.\n Answer: "))
    if answer_2 == 8:
        print("You are correct!\n")
        return 1
    else:
        print("Sorry, that's wrong, the correct answer is actually 8.\n")
        return 0
        
def question_3():
    '''
    The function question_3() is a true\false (boolean) question, it accepts no arguments and returns 1 if the user gets the answer correct and zero if the user answers incorrectly. 

    '''
    answer_3 = bool(int(input("3. True or False: Manny believes his father (Javier) doesn't need to sleep because he was struck by lightning.\n (Please enter 1 for True or 0 for False)\n Answer: ")))
    if answer_3 == False:
        print("You are correct!")
        print("Manny actually believes his father can drink as much as he wants because he was struck by lightning!\n")
        return 1
    else:
        print("Sorry, the answer is actually False (0).")
        print("Manny actually believes his father can drink as much as he wants because he was struck by lightning!\n")
        return 0
   

def question_4():
    '''
    The fucntion question_4() is a mutliple choice question, it accepts no arguments and returns 1 if the user gets the answer correct and zero if the user answers incorrectly.

    '''
    print("4. Which holiday does Cam loathe because of a childhood tragedy?\n Please enter a character a-e.")
    answer_4 = input(" a. Christmas\n b. Easter\n c. Thanksgiving\n d. New Years\n e. Halloween\n Answer: ")
    if answer_4 == "e":
        print("You are correct!\n")
        return 1
    else:
        print("Sorry, the answer is actually Halloween (e).\n")
        return 0
        
def question_5():
    '''
    The function question_5() is a numeric response question, it accepts no arguments and returns 1 if the user gets the answer correct and zero if the user answers incorrectly. 
    '''
    answer_5 = int(input("5. How many senior citizens does Phil take to the voting station on election day?\n Answer: "))
    if answer_5 == 1:
        print("You are correct!\n")
        return 1
    else:
        print("Sorry, the answer is actually 1.\n")
        return 0
        
def question_6():
    '''
    The function question_6() is a true\false (boolean) question, it accepts no arguments and returns 1 if the user gets the answer correct and zero if the user answers incorrectly. 

    '''
    answer_6 = bool(int(input("6. True or False: Gloria kissed Phil in the Season 1 finale.\n (Please enter 1 for True or 0 for False)\n Answer: ")))
    if answer_6 == True:
        print("You are correct!\n")
        return 1
    else:
        print("Sorry, the answer is actually True (1).\n")
        return 0
    

def question_7():
    '''
    The function question_7() has a mutliple choice question, it accepts no arguments and returns 1 if the user gets the answer correct and zero if the user answers incorrectly.
    '''
    print("7. Why does Phil have a fear of clowns?\n Please enter a character a-e.")
    answer_7 = input(" a. He found a dead clown in the woods as a child.\n b. His mother had an affair with a clown.\n c. A drunk clown ruined his 12th birthday.\n d. He is just scared of clowns.\n e. He watched Stephen King's \"It\" movie.\n Answer: ")
    if answer_7 == "a":
        print("You are correct!\n")
        return 1
    else:
        print("Sorry, that's wrong, the correct answer is actually \"He found a dead clown in the woods as a child.\" (a).\n")
        return 0

def question_8():
    '''
    The function question_8() is a true\false (boolean) question, it accepts no arguments and returns 1 if the user gets the answer correct and zero if the user answers incorrectly. 
    '''
    answer_8 = bool(int(input("8. True or False: Jay stated that his proudest accomplishment as a father was when Mitch took off his flaming red skating unitard.\n (Please enter 1 for True or 0 for False)\n Answer: ")))
    if answer_8 == True:
        print("You are correct!\n")
        return 1
    else:
        print("Sorry, the answer is actually True (1).\n")
        return 0

def question_9():
    '''
    The function question_9() has a mutliple choice question, it accepts no arguments and returns 1 if the user gets the answer correct and zero if the user answers incorrectly.
    '''
    print("9. Which actor plays Manny's father, Javier Delgado?\n Please enter a character a-e.")
    answer_9 = input(" a. Antonio Banderas\n b. Benjamin Bratt\n c. Adam Rodriguez\n d. Ricky Martin\n e. Enrique Iglesias\n Answer: ")
    if answer_9 == "b":
        print("You are correct!\n")
        return 1
    else:
        print("Sorry, that's wrong, the correct answer is actually Benjamin Bratt (b).\n")
        return 0

def question_10():
    '''
    The function question_10() is a true\false (boolean) question, it accepts no arguments and returns 1 if the user gets the answer correct and zero if the user answers incorrectly. 
    '''
    answer_10 = bool(int(input("10. True or False: Phil knows all of the dances from the movie High School Musical.\n (Please enter 1 for True or 0 for False)\n Answer: ")))
    if answer_10 == True:
        print("You are correct!\n")
        return 1
    else:
        print("Sorry, the answer is actually True (1).\n")
        return 0

import urllib.request

def format_search_term(search_term):
    '''
    111 students: no need to call this function
    To prepare the search term string for the query:
    1. remove comma
    2. replace spaces with +
    '''
    search_term = search_term.replace(",", "")
    search_term = search_term.replace(" ", "+")
    return search_term
  
def build_query(query):
    '''
    111 students: no need to call this function
    Builds the query string for the Spotify Search API according to this website:
    https://developer.spotify.com/web-api/console/get-search-item/
    '''
    query_base = "https://api.spotify.com/v1/search?q="    
    query = query_base + query
    # perform a track search and only return the top result
    query += "&type=track&limit=1"
    return query
    
def extract_numeric_value(results_str, label):
    '''
    111 students: no need to call this function
    Extracts an integer value represented by the label parameter from the JSON response.
    '''
    index = results_str.find(label)
    results_str = results_str[index:]
    index = results_str.find(":")
    results_str = results_str[index + 2:]
    index = results_str.find(",")
    results_str = results_str[:index]
    value = int(results_str)
    return value
    
def get_track_popularity(track, artist):
    '''
    111 STUDENTS: THIS IS THE FUNCTION YOU WILL CALL
    Accepts 3 strings representing a track and its artist
    Returns the popularity for track and artist
    '''
    track = format_search_term(track)
    artist = format_search_term(artist)
    
    # search the spotify database for a track by artist
    search_terms = track + "+" + artist
    
    query = build_query(search_terms)

    web_obj = urllib.request.urlopen(query)
    # web_obj.read() returns an array of bytes, need to convert to a string
    results_str = str(web_obj.read())
    web_obj.close()
    
    info = extract_numeric_value(results_str, "popularity")
    return info
    
def question_11():
    '''
    The function question_11() is a numeric response question, it accepts no arguments and returns 1 if the user gets the answer correct and zero if the user answers incorrectly.
    '''
    print("Fun fact: in Modern Family's very first episode ever, Phil sings and dances to the song \"We're All In This Together\"\n ")
    answer_11 = int(input("Bonus Question: On a scale of 1 (least popular) to 100 (most popular), what is the current Spotify popularity of \"We're All In This Together\".\n (Please enter an integer) Answer: "))
    track = "We're All In This Together"
    artist = "High School Musical Cast"
    popularity = get_track_popularity(track,artist)
    if answer_11 == popularity:
        print("You are correct! Good job!\n")
        return 1
    elif 40 <= answer_11 <= 50:
        print("You were so close, but the answer is actually 48!\n")
        return 0
    else:
        print("Sorry, the answer is actually 48.\n")
        return 0

    
def main():
    '''
    The function main() drives the program by calling all of the functions, it returns nothing, and accepts no parameters.
    '''
    total_score = question_1() + question_2() + question_3() + question_4() + question_5() + question_6() + question_7() + question_8() + question_9() + question_10()
    bonus = question_11()
    print("You answered %d out of 10 questions correctly!"%(total_score))
    print("You also got %d out of 1 bonus questions right!\n\n"%(bonus))
    if total_score == 10:
        print("Holy moly! You either work for the show or you have it on a continuous loop on your TV! Good job!")
    elif 8 <= total_score <= 9:
        print("Wow! You really know your stuff!")
    elif 5 <= total_score <= 7:
        print("You did all right, but to be a true fan, you should study up!")
    else:
        print("You sure you've ever even seen Modern Family?")
    
main()

#Citations:
#Gina Sprint
#Izak Kam
#http://nbviewer.jupyter.org/github/gsprint23/cpts111/blob/master/progassignments/PA3.ipynb
#https://en.wikipedia.org/wiki/List_of_Modern_Family_characters
#http://www.absurdtrivia.com/quiz/010583/modern-family-trivia/
#http://www.fanpop.com/clubs/modern-family/quiz/show/376827/who-plays-mannys-dad-episode