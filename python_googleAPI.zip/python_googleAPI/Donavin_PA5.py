#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Apr  5 21:21:50 2017

@author: kelseydonavin
"""

#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Mar 30 10:58:01 2017

@author: kelseydonavin
"""

#Programmer: Kelsey Donavin
#Class: CptS 111-01, Spring 2017
#Programming Assignment 5
#4/5/2017
#
#Description: Simple trip analyzer, shows statistics for a road trip.
import urllib.request

import webbrowser
    
def display_intro():
    '''
    This function has no parameters, and returns no values. It just displays the program overview.
    '''
    print("Welcome to the Road Trip Analyzer!\n\n")
    print("This program will read in a start and end destination, waypoints, and the amount of days spent at each waypoint.\n")
    print("The program will then write the trip statistics to an output file. Have fun! :) \n\n")
    
def open_trip_file():
    '''
    This function opens the txt file "roadtrip.txt"; it has no parameters,and returns the variable trip_infile.
    '''
    trip_infile = open("roadtrip.txt","r")
    return trip_infile

def start_place(trip_infile):
    '''
    This function reads in the start location from the trip_infile, it accepts one parameter (trip_infile) and returns the variable (trip_start).
    '''
    trip_start = trip_infile.readline().strip()
    trip_infile.readline()
    print("\nRoad trip origin: %s"%(trip_start))
    return trip_start

def get_waypoints(trip_infile):
    '''
    This function gets the waypoints for the trip, it accepts one argument (trip_infile), and returns the variable (destination).
    '''
    while True:
        waypoint = trip_infile.readline().strip()
        days_str = trip_infile.readline().strip()
        if days_str == "":
            break
        days_int = int(days_str)
        if days_int == 1:
            print("Processing waypoint %s (%d day)..."%(waypoint,days_int))
        else:
            print("Processing waypoint %s (%d days)..."%(waypoint,days_int))
        trip_infile.readline()
    destination = waypoint
    print("Road trip destination: %s\n\n" %(destination))
    return destination
        
        
def create_output_file():
    '''
    This function creates a new file to write to ("roadtrip_stats.txt"), it accepts no parameters, and returns the variable (trip_outfile).
    '''
    trip_outfile = open("roadtrip_stats.txt","w")
    return trip_outfile

def write_to_outfile(trip_infile,trip_outfile,trip_start,destination):
    '''
    This function writes to the output file ("roadtrip_stats.txt"), it accepts four arguments (trip_infile,trip_outfile,trip_start,destination), and returns no values.
    '''
    trip_infile.readline()
    trip_infile.readline()
    print("Writing stats to \"roadtrip_stats.txt\"....")
    total_days = 0
    num_waypoints = 0
    total_miles = 0
    waypoint_string = ""
    prev1_city = trip_start
    max_dist = -1
    max_days = -1
    max_dist_place1 = None
    max_dist_place2 = None
    max_days_place = None
    trip_outfile.write("\n")
    trip_outfile.write("---------------------------- Road Trip Distances ----------------------------\n\n")
    while True:
        waypoint = trip_infile.readline().strip()
        if waypoint != "Pocatello, ID":
            if waypoint == "Glasgow, MT":
                waypoint_withline = waypoint
            else:
                waypoint_withline = waypoint + "|"
            waypoint_string += format_city_string(waypoint_withline)
        days_str = trip_infile.readline().strip()
        if days_str == "":
            break
        days_int = int(days_str)
        if max_days == -1 or days_int > max_days:
            max_days = days_int
            max_days_place = waypoint
        total_days += days_int
        num_waypoints += 1
        trip_infile.readline()
        prev2_city = waypoint
        distance_between = get_distance(prev1_city,prev2_city)
        distance_miles = distance_between / 1609.34
        total_miles += distance_miles
        if max_dist == -1 or distance_miles > max_dist:
            max_dist = distance_miles
            max_dist_place1 = prev1_city
            max_dist_place2 = prev2_city
        trip_outfile.write("%s to %s: %.2f miles\n"%(prev1_city,prev2_city,distance_miles))
        prev1_city = prev2_city
    destination = waypoint
    distance_end = get_distance(prev1_city,destination)
    distance_end_miles = distance_end / 1609.34
    if distance_end_miles > max_dist:
        max_dist = distance_end_miles
        max_dist_place1 = prev1_city
        max_dist_place2 = destination
    total_miles += distance_end_miles
    avg_dist = total_miles / num_waypoints
    avg_days = total_days / num_waypoints
    trip_outfile.write("%s to %s: %.2f miles\n\n"%(prev1_city,destination,distance_end_miles))
    trip_outfile.write("\n------------------------------ Road Trip Stats ------------------------------\n\n")
    trip_outfile.write("Number of waypoints: %d\n\n"%(num_waypoints))
    trip_outfile.write("Total days spent at waypoints: %d days\n\n"%(total_days))
    trip_outfile.write("Total miles traveled: %.2f miles\n\n"%(total_miles))
    trip_outfile.write("Longest distance between waypoints: %.2f miles (%s to %s)\n\n"%(max_dist,max_dist_place1,max_dist_place2))
    trip_outfile.write("Longest amount of days spent at a waypoint: %d days (%s)\n\n"%(max_days,max_days_place))
    trip_outfile.write("Average distance between waypoints: %.2f miles\n\n"%(avg_dist))
    trip_outfile.write("Average amount of days at one waypoint: %.2f days\n\n"%(avg_days))
    return waypoint_string

def format_city_string(city_str):
    '''
    111 students: no need to call this function
    To prepare the city string for the query:
    1. remove comma
    2. replace spaces with +
    '''
    city_str = city_str.replace(",", "")
    city_str = city_str.replace(" ", "+")
    return city_str
  
def build_query(origin, dest):
    '''
    111 students: no need to call this function
    Builds the query string for the Google Distance Matrix API according to this website:
    https://developers.google.com/maps/documentation/distance-matrix/start
    '''
    query_base = "http://maps.googleapis.com/maps/api/distancematrix/json?origins="    
    query = query_base + origin
    query += "&destinations="
    query += dest
    query += "&mode=driving&sensor=false"
    return query
    
def extract_distance(results_str):
    '''
    111 students: no need to call this function
    Extracts the distance in meters from the JSON response.
    '''
    index = results_str.find("distance")
    results_str = results_str[index:]
    index = results_str.find("value")
    results_str = results_str[index:]
    index = results_str.find(":")
    results_str = results_str[index + 2:]
    index = results_str.find(r"\n")
    results_str = results_str[:index]
    dist = int(results_str)
    return dist
    
def get_distance(city1, city2):
    '''
    111 STUDENTS: THIS IS THE FUNCTION YOU WILL CALL
    Accepts 2 strings representing cities in the U.S.
    Returns the integer distance in meters between city1 and city2
    '''
    city1 = format_city_string(city1)
    city2 = format_city_string(city2)
    
    query = build_query(city1, city2)

    web_obj = urllib.request.urlopen(query)
    # web_obj.read() returns an array of bytes, need to convert to a string
    results_str = str(web_obj.read())
    web_obj.close()
    
    dist = extract_distance(results_str)
    return dist

def bonus_iframe(api_key,origin_str,destination_str,waypoint_string):
    '''
    This is part of the bonus, it accepts four parameters (api_key,origin_str,destination_str,waypoint_string), and returns the src string.
    '''
    width="450"
    height="250"
    frameborder="0" 
    style="border:0"
    src = "https://www.google.com/maps/embed/v1/directionskey=%s&origin=%s&destination=%s&waypoints=%s&mode=driving"%(api_key,origin_str,destination_str,waypoint_string) 
    return src

def bonus_iframe_to_file(src):
    '''
    This is part of the bonus, it accepts one parameter (src), and returns no values.
    '''
    roadtrip_html_file = open("roadtrip.html","w")
    roadtrip_html_file.write(src)
    #webbrowser.open("roadtrip.html")

  
def main():
    '''
    This function runs the program by calling several functions, it accepts no parameters, and returns no values.
    '''
    display_intro()
    trip_infile = open_trip_file()
    print("Reading in stop information from \"roadtrip.txt\"...")
    trip_start = start_place(trip_infile)
    destination = get_waypoints(trip_infile)
    trip_outfile = create_output_file()
    trip_infile.close()
    trip_infile = open_trip_file()
    waypoint_string = write_to_outfile(trip_infile,trip_outfile,trip_start,destination)
    origin_str = format_city_string(trip_start)
    destination_str = format_city_string(destination)
    print("Launching Google Maps for this roadtrip....")
    api_key = "AIzaSyCOzQwU7YcfaxRTQk97s-CHBfveATPKbXQ"
    src = bonus_iframe(api_key,origin_str,destination_str,waypoint_string)
    bonus_iframe_to_file(src)
    webbrowser.open("roadtrip.html")
    print("\n\nClosing files...\n")
    trip_infile.close()
    trip_outfile.close()
    print("Done.")
    
main()

#Citations:
#Gina Sprint
#Izak Kam
#http://nbviewer.jupyter.org/github/gsprint23/cpts111/blob/master/progassignments/PA5.ipynb